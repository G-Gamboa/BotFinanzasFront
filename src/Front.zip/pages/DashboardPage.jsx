import { useEffect, useMemo, useState } from "react";
import { api } from "../api/client";
import Layout from "../components/Layout";
import MovimientoForm from "../components/MovimientoForm";
import SectionCard from "../components/SectionCard";
import StatCard from "../components/StatCard";
import { getTelegramUser } from "../lib/telegram";
import { getPaletteByUser } from "../theme";

export default function Dashboard() {
  const tgUser = useMemo(() => getTelegramUser(), []);
  const palette = useMemo(() => getPaletteByUser(tgUser.id), [tgUser.id]);

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  async function loadDashboard() {
    try {
      setLoading(true);
      setErr("");
      const response = await api.getDashboard(tgUser.id);
      setData(response);
    } catch (error) {
      setErr(error.message || "No se pudo cargar el dashboard.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadDashboard();
  }, []);

  const userLabel = tgUser.username ? `@${tgUser.username}` : `ID ${tgUser.id}`;

  if (loading) {
    return (
      <Layout
        title="Dashboard"
        subtitle="Cargando información..."
        userLabel={userLabel}
        userId={tgUser.id}
      >
        <div style={{ color: palette.textSoft }}>Cargando...</div>
      </Layout>
    );
  }

  if (err) {
    return (
      <Layout
        title="Dashboard"
        subtitle="Hubo un problema al cargar"
        userLabel={userLabel}
        userId={tgUser.id}
      >
        <div style={{ color: palette.danger, fontWeight: 700 }}>{err}</div>
      </Layout>
    );
  }

  const networthQ = data?.networth?.networth_q ?? 0;
  const netoQ = data?.neto?.neto_q ?? 0;
  const totalDeudas = data?.total_deudas ?? 0;
  const deudasActivas = data?.deudas_activas?.length ?? 0;

  return (
    <Layout
      title={`Hola, ${tgUser.first_name}`}
      subtitle="Resumen general de tus finanzas"
      userLabel={userLabel}
      userId={tgUser.id}
    >
      <div
        style={{
          display: "grid",
          gap: "1rem",
          gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))",
          marginBottom: "1rem",
        }}
      >
        <StatCard palette={palette} title="Networth" value={money(networthQ)} />
        <StatCard palette={palette} title="Neto" value={money(netoQ)} accent />
        <StatCard palette={palette} title="Deudas activas" value={String(deudasActivas)} />
        <StatCard palette={palette} title="Total deudas" value={money(totalDeudas)} accent />
      </div>

      <div
        style={{
          display: "grid",
          gap: "1rem",
          gridTemplateColumns: "1.2fr 1fr",
        }}
      >
        <div style={{ display: "grid", gap: "1rem" }}>
          <SectionCard palette={palette} title="Nuevo movimiento" accent>
            <MovimientoForm
              palette={palette}
              userId={tgUser.id}
              catalogos={data?.catalogos || {}}
              onSaved={loadDashboard}
            />
          </SectionCard>

          <SectionCard palette={palette} title="Saldos por cuenta">
            <div style={{ display: "grid", gap: "0.7rem" }}>
              {Object.entries(data?.saldos || {}).map(([cuenta, saldo]) => (
                <div
                  key={cuenta}
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "0.85rem 1rem",
                    borderRadius: "1rem",
                    border: `1px solid ${palette.borderSoft || palette.border}`,
                    background: palette.cardSoft,
                  }}
                >
                  <span style={{ color: palette.text, fontWeight: 700 }}>{cuenta}</span>
                  <span style={{ color: palette.primary, fontWeight: 800 }}>{money(saldo)}</span>
                </div>
              ))}
            </div>
          </SectionCard>
        </div>

        <div style={{ display: "grid", gap: "1rem" }}>
          <SectionCard palette={palette} title="Deudas activas" accent>
            {(data?.deudas_activas || []).length === 0 ? (
              <div style={{ color: palette.textSoft }}>No tienes deudas activas.</div>
            ) : (
              <div style={{ display: "grid", gap: "0.8rem" }}>
                {data.deudas_activas.map((deuda) => (
                  <div
                    key={deuda.row}
                    style={{
                      background: palette.cardSoft,
                      border: `1px solid ${palette.borderSoft || palette.border}`,
                      borderRadius: "1rem",
                      padding: "0.9rem 1rem",
                    }}
                  >
                    <div style={{ fontWeight: 800, color: palette.text }}>
                      {deuda.nombre}
                    </div>
                    <div style={{ fontSize: "0.92rem", color: palette.textSoft, marginTop: "0.2rem" }}>
                      {deuda.acreedor}
                    </div>
                    <div style={{ marginTop: "0.55rem", color: palette.primary, fontWeight: 800 }}>
                      Saldo: {money(deuda.saldo)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </SectionCard>

          <SectionCard palette={palette} title="Resumen del mes">
            <div style={{ display: "grid", gap: "0.6rem" }}>
              <Row label="Ingresos" value={money(data?.resumen_mes?.ingresos || 0)} palette={palette} />
              <Row label="Egresos" value={money(data?.resumen_mes?.egresos || 0)} palette={palette} />
              <Row label="Balance" value={money(data?.resumen_mes?.balance || 0)} palette={palette} />
            </div>
          </SectionCard>

          <SectionCard palette={palette} title="Resumen semanal">
            <div style={{ display: "grid", gap: "0.6rem" }}>
              <Row label="Ingresos" value={money(data?.resumen_semana?.ingresos || 0)} palette={palette} />
              <Row label="Egresos" value={money(data?.resumen_semana?.egresos || 0)} palette={palette} />
              <Row label="Balance" value={money(data?.resumen_semana?.balance || 0)} palette={palette} />
            </div>
          </SectionCard>
        </div>
      </div>
    </Layout>
  );
}

function Row({ label, value, palette }) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        padding: "0.75rem 0.9rem",
        borderRadius: "0.9rem",
        background: palette.cardSoft,
        border: `1px solid ${palette.borderSoft || palette.border}`,
      }}
    >
      <span style={{ color: palette.textSoft, fontWeight: 700 }}>{label}</span>
      <span style={{ color: palette.text, fontWeight: 800 }}>{value}</span>
    </div>
  );
}

function money(value) {
  return `Q ${Number(value || 0).toLocaleString("es-GT", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}